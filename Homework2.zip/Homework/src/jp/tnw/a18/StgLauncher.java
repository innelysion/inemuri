package jp.tnw.a18;

public class StgLauncher extends StgUnitBase{

}
