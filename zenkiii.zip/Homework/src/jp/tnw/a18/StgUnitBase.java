package jp.tnw.a18;

import java.awt.Graphics2D;

import javax.swing.JFrame;

public class StgUnitBase extends StgObject {

	StgUnitBase(){

	}

	@Override
	void drawImage(Graphics2D g, JFrame wind) {
		// TODO 自動生成されたメソッド・スタブ

	}



}
