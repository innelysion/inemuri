package jp.tnw.a18;

//使いたいｸﾗｽの取り込み
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class GameMain {

	JFrame wind = new JFrame("前期課題まとめA18");// JFrame の初期化(ﾒﾆｭｰﾊﾞｰの表示ﾀｲﾄﾙ
	Insets sz;// ﾒﾆｭｰﾊﾞｰのｻｲｽﾞ
	BufferStrategy offimage;// ﾀﾞﾌﾞﾙﾊﾞｯﾌｧでちらつき防止
	Font f = new Font("Default", Font.BOLD, 13);// 使用するフォントクラス宣言
	VFX bom = new VFX();
	StgItem item = new StgItem();
	StgBullet bullet = new StgBullet();
	StgEnemy enemy = new StgEnemy();
	KadaiMoji mojiBomb = new KadaiMoji(0);
	KadaiMoji mojiWave = new KadaiMoji(1);
	KadaiMoji mojiFan = new KadaiMoji(2);
	KadaiMoji mojiFuriko = new KadaiMoji(3);
	StgPlayer player = new StgPlayer();
	Input input = new Input();
	BufferedImage bg;
	boolean[] display = { false, true, false, true, true };
	boolean mainStart = false;
	static boolean in = false, in1 = true, in2 = true, in3 = true, in4 = true, in5 = true;

	// -----------------------------
	// 初期化用の関数
	// ・window生成
	// ・window大きさの指定
	// ・windowの場所
	// -----------------------------

	GameMain() {

		// Load System data
		Sys.setup();
		// Setup window & inputs & graphics
		wind.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// 閉じﾎﾞﾀﾝ許可
		wind.setBackground(new Color(0, 0, 0));// 色指定
		wind.setResizable(false);// ｻｲｽﾞ変更不可
		wind.setVisible(true);// 表示or非表示
		sz = wind.getInsets();// ﾒﾆｭｰﾊﾞｰのｻｲｽﾞ
		wind.setSize(Sys.windSizeX + sz.left + sz.right, Sys.windSizeY + sz.top + sz.bottom);// ｳｨﾝﾄﾞｳのｻｲｽﾞ
		wind.setLocationRelativeTo(null);// 中央に表示
		wind.setIgnoreRepaint(true);// JFrameの標準書き換え処理無効
		wind.createBufferStrategy(2);// 2でﾀﾞﾌﾞﾙ
		offimage = wind.getBufferStrategy();
		// For input class
		wind.addMouseListener(input);
		wind.addMouseMotionListener(input);
		wind.addKeyListener(input);
		wind.addMouseWheelListener(input);
		// Load game data and resources
		bom.Load();
		item.loadImage("Image/Item", 1);
		bullet.loadImage("Image/tama", 1);
		enemy.loadImage("Image/zako", 1);
		player.loadImage("Image/jiki2", 1);
		mojiBomb.loadImage("Image/moji", 1);
		mojiWave.loadImage("Image/moji", 1);
		mojiFan.loadImage("Image/moji", 1);
		mojiFuriko.loadImage("Image/moji", 1);
		try {
			bg = ImageIO.read(getClass().getResource("Image/bg_02.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Setup timer task
		Timer TM = new Timer();// ﾀｲﾏｰｸﾗｽの実体化
		TM.schedule(new timer_TSK(), 17, 17);// 17ms後から 17msおきに
		// どこ？ 17[ms]=プログラムが動き出す最初の時間
		// 17[ms]その後は17[ms]繰り返し

	}// Main_Game end

	// ---------------------------
	// ﾀｲﾏｰｸﾗｽ 1/60秒で1回動作
	// extends=継承
	// ---------------------------
	class timer_TSK extends TimerTask {

		public void run() {

			// Game data update
			input.update(wind);
			menuCheck();
			if (mainStart) {
				mainUpdate();
			}

			// Garphics update
			Graphics g2 = offimage.getDrawGraphics();// ｸﾞﾗﾌｨｯｸ初期化
			Graphics2D g = (Graphics2D) g2;

			if (offimage.contentsLost() == false) {//
				// Clear the graphic for next frame
				g.translate(sz.left, sz.top); // ﾒﾆｭｰﾊﾞｰのｻｲｽﾞ補正
				g.clearRect(0, 0, Sys.windSizeX, Sys.windSizeY); // 画面ｸﾘｱ(左上X、左上Y、右下x、右下y)
				drawMenu(g);
				if (mainStart) {
					drawMain(g);
				}
				g.drawString("A18 チョウ カンフ 前期課題", Sys.windSizeX - 170 - 15, Sys.windSizeY - 10);
				offimage.show();// ﾀﾞﾌﾞﾙﾊﾞｯﾌｧの切り替え
				g.dispose();// ｸﾞﾗﾌｨｯｸｲﾝｽﾀﾝｽの破棄

			} // if end ｸﾞﾗﾌｨｯｸOK??

		}// run end

		private void drawMain(Graphics2D g) {
			// TODO Auto-generated method stub
			g.drawImage(bg, 0, 0, Sys.windSizeX, Sys.windSizeY, 0, 0, bg.getWidth(), bg.getHeight(), wind);
			bom.draw(g, wind);

			if (display[0] == true) {
				mojiBomb.drawImage(g, wind);
			}
			if (display[1] == true) {
				mojiWave.drawImage(g, wind);
			}
			if (display[2] == true) {
				mojiFan.drawImage(g, wind);
			}
			if (display[3] == true) {
				mojiFuriko.drawImage(g, wind);
			}
			if (display[4] == true) {
				enemy.drawImage(g, wind);
				item.drawImage(g, wind);
			}
			player.drawImage(g, wind);
			bullet.drawImage(g, wind);
		}

		private void mainUpdate() {
			// TODO Auto-generated method stub
			bom.UpDate();

			bullet.update(bom);

			if (display[0] == true) {
				mojiBomb.update(bullet, bom);
			}
			if (display[1] == true) {
				mojiWave.update(bullet, bom);
			}
			if (display[2] == true) {
				mojiFan.update(bullet, bom);
			}
			if (display[3] == true) {
				mojiFuriko.update(bullet, bom);
			}
			if (display[4] == true) {
				item.update();
				enemy.update(bullet, bom, item);
			}
			player.update();
		}

		private void drawMenu(Graphics2D g) {
			// TODO Auto-generated method stub
			g.setColor(Color.darkGray);// 色指定
			g.fillRect(0, 0, Sys.windSizeX, Sys.windSizeY);// 塗りつぶし
			g.setFont(f);
			g.setColor(Color.WHITE);
			if (!mainStart) {
				// g.drawString("★矢印キーで移動 ★SHIFTキーで低速移動 ★Zキーで射撃
				// ★Xキーで強制パワーアップ", 10, 15);
				g.drawString("【　】当たり判定とパワーアップ最終課題", 550 + (isMouseIn(1) ? 1 : 0), 200 + (isMouseIn(1) ? 1 : 0));
				g.drawString("【　】前期Ⅰ花火", 550 + (isMouseIn(2) ? 1 : 0), 230 + (isMouseIn(2) ? 1 : 0));
				g.drawString("【　】前期Ⅱヘビ", 550 + (isMouseIn(3) ? 1 : 0), 260 + (isMouseIn(3) ? 1 : 0));
				g.drawString("【　】前期Ⅲ扇風機", 550 + (isMouseIn(4) ? 1 : 0), 290 + (isMouseIn(4) ? 1 : 0));
				g.drawString("【　】前期Ⅳ振り子", 550 + (isMouseIn(5) ? 1 : 0), 320 + (isMouseIn(5) ? 1 : 0));
				if (display[4]) {
					g.drawString("◆", 564 + (isMouseIn(1) ? 1 : 0), 200 + (isMouseIn(1) ? 1 : 0));
				}
				if (display[0]) {
					g.drawString("◆", 564 + (isMouseIn(2) ? 1 : 0), 230 + (isMouseIn(2) ? 1 : 0));
				}
				if (display[1]) {
					g.drawString("◆", 564 + (isMouseIn(3) ? 1 : 0), 260 + (isMouseIn(3) ? 1 : 0));
				}
				if (display[2]) {
					g.drawString("◆", 564 + (isMouseIn(4) ? 1 : 0), 290 + (isMouseIn(4) ? 1 : 0));
				}
				if (display[3]) {
					g.drawString("◆", 564 + (isMouseIn(5) ? 1 : 0), 320 + (isMouseIn(5) ? 1 : 0));
				}
				g.drawString("★ 表示したい課題にチェックを入れてください ★", Sys.windSizeX / 2 - 365, Sys.windSizeY / 2 - 60);

				if (isMouseIn(0) && Input.M_LC) {
					g.setColor(Color.LIGHT_GRAY);// 色指定
					g.fillRoundRect(231, 246, 100, 30, 10, 12);
				} else {
					g.setColor(Color.BLACK);// 色指定
					g.fillRoundRect(230, 245, 100, 30, 10, 12);
				}

				g.setColor(Color.WHITE);
				g.drawString("START", 260 + (isMouseIn(0) ? 1 : 0), 265 + (isMouseIn(0) ? 1 : 0));
				g.drawString(String.valueOf(Input.M_X) + " , " + String.valueOf(Input.M_Y), 20, 20);
			}
		}

		private void menuCheck() {
			// TODO Auto-generated method stub
			if (!mainStart && isMouseIn(0) && in && !Input.M_LC) {
				mainStart = true;
			}
			if (!mainStart && isMouseIn(0) && Input.M_LC) {
				in = true;
			} else {
				in = false;
			}

			if (!mainStart && isMouseIn(1) && Input.M_LC) {
				if (in1) {
					if (display[4]) {
						display[4] = false;
					} else {
						display[4] = true;
					}
					in1 = false;
				}
			}
			if (!mainStart && isMouseIn(2) && Input.M_LC) {
				if (in2) {
					if (display[0]) {
						display[0] = false;
					} else {
						display[0] = true;
					}
					in2 = false;
				}
			}
			if (!mainStart && isMouseIn(3) && Input.M_LC) {
				if (in3) {
					if (display[1]) {
						display[1] = false;
					} else {
						display[1] = true;
					}
					in3 = false;
				}
			}
			if (!mainStart && isMouseIn(4) && Input.M_LC) {
				if (in4) {
					if (display[2]) {
						display[2] = false;
					} else {
						display[2] = true;
					}
					in4 = false;
				}
			}
			if (!mainStart && isMouseIn(5) && Input.M_LC) {
				if (in5) {
					if (display[3]) {
						display[3] = false;
					} else {
						display[3] = true;
					}
					in5 = false;
				}
			}

		}

		private boolean isMouseIn(int num) {
			// TODO Auto-generated method stub
			switch (num) {
			case 0:
				return (Input.M_X >= 230 && Input.M_X <= 330 && Input.M_Y >= 245 && Input.M_Y <= 275);
			case 1:
				return (Input.M_X >= 550 && Input.M_X <= 830 && Input.M_Y >= 185 && Input.M_Y <= 205);
			case 2:
				return (Input.M_X >= 550 && Input.M_X <= 670 && Input.M_Y >= 215 && Input.M_Y <= 235);
			case 3:
				return (Input.M_X >= 550 && Input.M_X <= 670 && Input.M_Y >= 245 && Input.M_Y <= 265);
			case 4:
				return (Input.M_X >= 550 && Input.M_X <= 670 && Input.M_Y >= 275 && Input.M_Y <= 295);
			case 5:
				return (Input.M_X >= 550 && Input.M_X <= 670 && Input.M_Y >= 305 && Input.M_Y <= 325);
			}
			return false;
		}

	}// timer task class end
		// -----------------------------------
		// Main ここからプログラムが動く
		// -----------------------------------

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		// Main_GameのｸﾗｽをGMという名前で動かします
		// 動かす前に初期化してから動かす！！

		@SuppressWarnings("unused")
		GameMain Game = new GameMain();

	}

}