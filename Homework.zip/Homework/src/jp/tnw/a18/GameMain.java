package jp.tnw.a18;

//使いたいｸﾗｽの取り込み
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.image.BufferStrategy;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;

public class GameMain {

	JFrame wind = new JFrame("STGProject");// JFrame の初期化(ﾒﾆｭｰﾊﾞｰの表示ﾀｲﾄﾙ
	Insets sz;// ﾒﾆｭｰﾊﾞｰのｻｲｽﾞ
	BufferStrategy offimage;// ﾀﾞﾌﾞﾙﾊﾞｯﾌｧでちらつき防止
	Font f = new Font("Default", Font.BOLD, 12);// 使用するフォントクラス宣言
	VFX bom = new VFX();
	StgItem item = new StgItem();
	StgBullet bullet = new StgBullet();
	StgEnemy enemy = new StgEnemy();
	KadaiMoji mojiBomb = new KadaiMoji(0);
	KadaiMoji mojiWave = new KadaiMoji(1);
	KadaiMoji mojiFan = new KadaiMoji(2);
	KadaiMoji mojiFuriko = new KadaiMoji(3);
	StgPlayer player = new StgPlayer();
	Input input = new Input();
	boolean[] display = { true, true, true, false };

	// -----------------------------
	// 初期化用の関数
	// ・window生成
	// ・window大きさの指定
	// ・windowの場所
	// -----------------------------
	GameMain() {

		// Load System data
		Sys.setup();
		// Setup window & inputs & graphics
		wind.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// 閉じﾎﾞﾀﾝ許可
		wind.setBackground(new Color(0, 0, 0));// 色指定
		wind.setResizable(false);// ｻｲｽﾞ変更不可
		wind.setVisible(true);// 表示or非表示
		sz = wind.getInsets();// ﾒﾆｭｰﾊﾞｰのｻｲｽﾞ
		wind.setSize(Sys.windSizeX + sz.left + sz.right, Sys.windSizeY + sz.top + sz.bottom);// ｳｨﾝﾄﾞｳのｻｲｽﾞ
		wind.setLocationRelativeTo(null);// 中央に表示
		wind.setIgnoreRepaint(true);// JFrameの標準書き換え処理無効
		wind.createBufferStrategy(2);// 2でﾀﾞﾌﾞﾙ
		offimage = wind.getBufferStrategy();
		// For input class
		wind.addMouseListener(input);
		wind.addMouseMotionListener(input);
		wind.addKeyListener(input);
		wind.addMouseWheelListener(input);
		// Load game data and resources
		bom.Load();
		item.loadImage("Image/Item", 1);
		bullet.loadImage("Image/tama", 1);
		enemy.loadImage("Image/zako", 1);
		player.loadImage("Image/jiki2", 1);
		mojiBomb.loadImage("Image/moji", 1);
		mojiWave.loadImage("Image/moji", 1);
		mojiFan.loadImage("Image/moji", 1);
		mojiFuriko.loadImage("Image/moji", 1);
		// Setup timer task
		Timer TM = new Timer();// ﾀｲﾏｰｸﾗｽの実体化
		TM.schedule(new timer_TSK(), 17, 17);// 17ms後から 17msおきに
		// どこ？ 17[ms]=プログラムが動き出す最初の時間
		// 17[ms]その後は17[ms]繰り返し

	}// Main_Game end

	// ---------------------------
	// ﾀｲﾏｰｸﾗｽ 1/60秒で1回動作
	// extends=継承
	// ---------------------------
	class timer_TSK extends TimerTask {

		public void run() {

			// Game data update
			input.update(wind);
			// item.update();
			bom.UpDate();
			bullet.update(bom);
			// enemy.update(bullet, bom, item);
			if (display[0] == true) {
				mojiBomb.update(bullet, bom);
			}
			if (display[1] == true) {
				mojiWave.update(bullet, bom);
			}
			if (display[2] == true) {
				mojiFan.update(bullet, bom);
			}
			if (display[3] == true) {
				mojiFuriko.update(bullet, bom);
			}
			player.update();

			// Garphics update
			Graphics g2 = offimage.getDrawGraphics();// ｸﾞﾗﾌｨｯｸ初期化
			Graphics2D g = (Graphics2D) g2;

			if (offimage.contentsLost() == false) {//
				// Clear the graphic for next frame
				g.translate(sz.left, sz.top); // ﾒﾆｭｰﾊﾞｰのｻｲｽﾞ補正
				g.clearRect(0, 0, Sys.windSizeX, Sys.windSizeY); // 画面ｸﾘｱ(左上X、左上Y、右下x、右下y)
				g.setColor(Color.darkGray);// 色指定
				g.fillRect(0, 0, Sys.windSizeX, Sys.windSizeY);// 塗りつぶし

				// Draw background

				// Draw game objects

				// Draw UI

				// g.setColor(Color.MAGENTA);// 色指定
				// g.setFont(f);
				// g.drawString("★矢印キーで移動 ★SHIFTキーで低速移動 ★Zキーで射撃 ★Xキーで強制パワーアップ",
				// 10, 15);
				// g.drawString("A18 チョウ カンフ", Sys.windSizeX - 115,
				// Sys.windSizeY - 15);
				// g.setColor(Color.WHITE);// 色指定
				// g.drawString("[POWER]", 10, 30);
				// g.drawString("[DIR8]", 10, 40);
				// g.drawString("[FACING]", 10, 50);
				// g.drawString(String.valueOf(StgPlayer.energy), 140, 30);
				// g.drawString(String.valueOf(Input.DIR8), 140, 40);
				// g.drawString(String.valueOf(StgPlayer.angle), 140, 50);

				// Draw others

				bom.draw(g, wind);

				// enemy.drawImage(g, wind);
				if (display[0] == true) {
					mojiBomb.drawImage(g, wind);
				}
				if (display[1] == true) {
					mojiWave.drawImage(g, wind);
				}
				if (display[2] == true) {
					mojiFan.drawImage(g, wind);
				}
				if (display[3] == true) {
					mojiFuriko.drawImage(g, wind);
				}
				player.drawImage(g, wind);
				bullet.drawImage(g, wind);
				// item.drawImage(g, wind);

				// ---------------------------------------------------
				offimage.show();// ﾀﾞﾌﾞﾙﾊﾞｯﾌｧの切り替え
				g.dispose();// ｸﾞﾗﾌｨｯｸｲﾝｽﾀﾝｽの破棄

			} // if end ｸﾞﾗﾌｨｯｸOK??

		}// run end

	}// timer task class end
		// -----------------------------------
		// Main ここからプログラムが動く
		// -----------------------------------

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		// Main_GameのｸﾗｽをGMという名前で動かします
		// 動かす前に初期化してから動かす！！

		GameMain Game = new GameMain();

	}

}