package jp.tnw.a18;

public class StgUnitBase extends StgObject {

	StgUnitBase(){
		
		
		
		
	}

}
