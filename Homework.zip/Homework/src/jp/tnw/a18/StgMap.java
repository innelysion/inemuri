package jp.tnw.a18;

public class StgMap {

}
